const slider = document.querySelectorAll(".slider");
const btnSinistra = document.querySelectorAll(".button_sinistraSeta");
const btnDestra = document.querySelectorAll(".button_destraSeta");
const slider2 = document.querySelectorAll(".slider2");
const btnSinistra2 = document.querySelectorAll(".button_sinistraSeta3");
const btnDestra2 = document.querySelectorAll(".button_destraSeta3");
const slider3 = document.querySelectorAll(".slider3");
const btnSinistra3 = document.querySelectorAll(".button_sinistraSeta3");
const btnDestra3 = document.querySelectorAll(".button_destraSeta3");

let currentSlide = 0;

function hideSlider() {
	//slider.forEach((item) => item.classList.remove("on"));
	slider[currentSlide].classList.remove("on");
}

function showSlider() {
	slider[currentSlide].classList.add("on");
}

function nextSlider() {
	hideSlider();

	if (currentSlide == slider.length - 1) {
		currentSlide = 0;
	} else {
		currentSlide++;
	}

	showSlider();
}

function prevSlider() {
	hideSlider();

	if (currentSlide == 0) {
		currentSlide = slider.length - 1;
	} else {
		currentSlide--;
	}

	showSlider();
}

btnDestra.forEach(function (btn) {
	btn.addEventListener("click", nextSlider);
});

btnSinistra.forEach(function (btn) {
	btn.addEventListener("click", prevSlider);
});

console.log(slider);
